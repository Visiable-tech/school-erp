@extends('layouts.admin')
@section('content')
<div class="container-fluid py-3">
<h3 class="text-success">Accounts & Payments</h3>
<div class="d-flex flex-wrap gap-2 mb-3"><a class="btn btn-outline-success" href="{{ route('accounts.index') }}">Accounts Dashboard</a><a class="btn btn-outline-success" href="{{ route('accounts.expenses') }}">Expense Register</a>@can('accounts.category.manage')<a class="btn btn-outline-success" href="{{ route('accounts.categories') }}">Expense Categories</a>@endcan @can('fee-head.view')<a class="btn btn-outline-secondary" href="{{ route('fees.dashboard') }}">Fee Dashboard</a>@endcan</div>
@if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
@if($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
<a class="btn btn-outline-success mb-3" href="{{ route('accounts.vendors.index') }}">Vendor Management</a>
@yield('accounts_content')
</div>
@endsection
