<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounts.view')): ?>
<div class="px-3 py-2"><a class="text-white text-decoration-none" href="<?php echo e(route('accounts.index')); ?>"><i class="bi bi-wallet2 me-2"></i>Accounts Dashboard</a></div>
<div class="px-3 py-2"><a class="text-white text-decoration-none" href="<?php echo e(route('accounts.expenses')); ?>"><i class="bi bi-receipt me-2"></i>Expense & Payments</a></div>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounts.category.manage')): ?><div class="px-3 py-2"><a class="text-white text-decoration-none" href="<?php echo e(route('accounts.categories')); ?>">Expense Categories</a></div><?php endif; ?>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounts.view')): ?><div class="px-3 py-2"><a class="text-white text-decoration-none" href="<?php echo e(route('accounts.vendors.index')); ?>">Vendor Management &amp; Payments</a></div><?php endif; ?>
<?php /**PATH C:\xampp\htdocs\school-erp\resources\views/accounts/sidebar.blade.php ENDPATH**/ ?>