

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
            'fee-cycle.view',
            'fee-head.view',
            'fee-structure.view',
            'fee-installment.view',

            'student-fee-assignment.view',
            'student-fee-assignment.create',
            'student-fee-assignment.bulk-create',

            'student-fee-due.view',

            'fee-collection.view',
            'fee-collection.create',
            'fee-collection.cancel',
            'fee-collection.receipt',

            'fee-component-group.view',

            'bank-master.view',
            'misc-fee-component.view',
            'school-account.view',
            'fee-receipt-scheme.view',
            'late-fee-fine.view',
            'concession-type.view',
            'payment-mode.view',
            'cheque-bounce-reason.view',

            'fee-compile.view',
            'fee-compile-queue.view',

            'student-fee-assignments.view',
            'optional-fee-assignments.view',

            'concession-assignment.view',
            'fee-waiver-assignment.view',
            'fine-waiver-assignment.view',
            'composite-concession.view',

            'fee-refunds.view',

            'cheque-dd.view',
            'cheque-dd.create',
            'cheque-dd.edit',
            'cheque-dd.deposit',
            'cheque-dd.clear',
            'cheque-dd.bounce',
            'cheque-dd.cancel'
        ])): ?>

            <?php

                /*
                |--------------------------------------------------------------------------
                | Fee Setup
                |--------------------------------------------------------------------------
                */

                $feeSetupOpen = request()->routeIs(
                    'fee-cycles.*',
                    'fee-component-groups.*',
                    'fee-heads.*',
                    'misc-fee-components.*',
                    'bank-masters.*',
                    'school-accounts.*',
                    'fee-structures.*',
                    'fee-receipt-schemes.*',
                    'late-fee-fines.*',
                    'concession-types.*',
                    'fee-installments.*',
                    'payment-modes.*',
                    'cheque-bounce-reasons.*',
                    'fee-compile.*',
                    'fee-compile-queues.*'
                );


                /*
                |--------------------------------------------------------------------------
                | Optional Assignments
                |--------------------------------------------------------------------------
                */

                $feeOptionalOpen = request()->routeIs(
                    'student-fee-assignments.*',
                    'optional-fee-assignments.*',
                    'concession-assignments.*',
                    'fee-waiver-assignments.*',
                    'fine-waiver-assignments.*',
                    'composite-concessions.*'
                );


                /*
                |--------------------------------------------------------------------------
                | Fee Collection
                |--------------------------------------------------------------------------
                */

                $feeCollectionOpen = request()->routeIs(
                    'fee-collections.*',
                    'fee-receipts.*',
                    'fee-refunds.*',
                    'cheque-dd-details.*'
                );


                /*
                |--------------------------------------------------------------------------
                | Main Fee Management
                |--------------------------------------------------------------------------
                */

                $feeManagementOpen =
                    request()->routeIs('fees.*')
                    ||
                    $feeSetupOpen
                    ||
                    $feeOptionalOpen
                    ||
                    $feeCollectionOpen;

            ?>


            

            <a
                data-bs-toggle="collapse"
                href="#feeManagementMenu"
                role="button"
                aria-expanded="<?php echo e($feeManagementOpen ? 'true' : 'false'); ?>"
                aria-controls="feeManagementMenu"
                class="<?php echo e($feeManagementOpen ? 'active' : ''); ?>"
            >

                <i class="bi bi-cash-stack"></i>

                <span class="flex-grow-1">
                    Fee Management
                </span>

                <i class="bi bi-chevron-down sidebar-arrow"></i>

            </a>


            

            <div
                class="collapse <?php echo e($feeManagementOpen ? 'show' : ''); ?>"
                id="feeManagementMenu"
            >

                <div class="sidebar-submenu">


                    

                    <a
                        href="<?php echo e(route('fees.dashboard')); ?>"
                        class="<?php echo e(request()->routeIs('fees.dashboard')
                            ? 'active'
                            : ''); ?>"
                    >

                        <i class="bi bi-speedometer2 me-2"></i>

                        Dashboard

                    </a>


                    

                    <a
                        data-bs-toggle="collapse"
                        href="#feeSetupMenu"
                        role="button"
                        aria-expanded="<?php echo e($feeSetupOpen ? 'true' : 'false'); ?>"
                        aria-controls="feeSetupMenu"
                        class="<?php echo e($feeSetupOpen ? 'active' : ''); ?>"
                    >

                        <i class="bi bi-gear me-2"></i>

                        <span class="flex-grow-1">
                            Setup
                        </span>

                        <i class="bi bi-chevron-down sidebar-arrow"></i>

                    </a>


                    <div
                        class="collapse <?php echo e($feeSetupOpen ? 'show' : ''); ?>"
                        id="feeSetupMenu"
                    >

                        <div class="sidebar-submenu">


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-cycle.view')): ?>

                                <a
                                    href="<?php echo e(route('fee-cycles.index')); ?>"
                                    class="<?php echo e(request()->routeIs('fee-cycles.*')
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Fee Cycles
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-component-group.view')): ?>

                                <a
                                    href="<?php echo e(route('fee-component-groups.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'fee-component-groups.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Fee Component Groups
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-head.view')): ?>

                                <a
                                    href="<?php echo e(route('fee-heads.index')); ?>"
                                    class="<?php echo e(request()->routeIs('fee-heads.*')
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Fee Components
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('misc-fee-component.view')): ?>

                                <a
                                    href="<?php echo e(route('misc-fee-components.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'misc-fee-components.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Misc. Components
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bank-master.view')): ?>

                                <a
                                    href="<?php echo e(route('bank-masters.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'bank-masters.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Banks Master
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('school-account.view')): ?>

                                <a
                                    href="<?php echo e(route('school-accounts.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'school-accounts.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    School Accounts
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-structure.view')): ?>

                                <a
                                    href="<?php echo e(route('fee-structures.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'fee-structures.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Fee Templates
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-receipt-scheme.view')): ?>

                                <a
                                    href="<?php echo e(route('fee-receipt-schemes.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'fee-receipt-schemes.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Receipt No. Scheme
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('late-fee-fine.view')): ?>

                                <a
                                    href="<?php echo e(route('late-fee-fines.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'late-fee-fines.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Late Fee Fine
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('concession-type.view')): ?>

                                <a
                                    href="<?php echo e(route('concession-types.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'concession-types.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Concession Types
                                </a>

                            <?php endif; ?>

                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment-mode.view')): ?>

                                <a
                                    href="<?php echo e(route('payment-modes.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'payment-modes.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Payment Modes
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cheque-bounce-reason.view')): ?>

                                <a
                                    href="<?php echo e(route('cheque-bounce-reasons.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'cheque-bounce-reasons.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Chq. Bounce Reasons
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('student-fee-assignment.bulk-create')): ?>

                                <a
                                    href="<?php echo e(route('fee-compile.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'fee-compile.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Compile Fee
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-compile-queue.view')): ?>

                                <a
                                    href="<?php echo e(route('fee-compile-queues.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'fee-compile-queues.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Fee Compile Queues
                                </a>

                            <?php endif; ?>


                        </div>

                    </div>


                    

                    <a
                        data-bs-toggle="collapse"
                        href="#feeOptionalMenu"
                        role="button"
                        aria-expanded="<?php echo e($feeOptionalOpen ? 'true' : 'false'); ?>"
                        aria-controls="feeOptionalMenu"
                        class="<?php echo e($feeOptionalOpen ? 'active' : ''); ?>"
                    >

                        <i class="bi bi-sliders me-2"></i>

                        <span class="flex-grow-1">
                            Optional Assignments
                        </span>

                        <i class="bi bi-chevron-down sidebar-arrow"></i>

                    </a>


                    <div
                        class="collapse <?php echo e($feeOptionalOpen ? 'show' : ''); ?>"
                        id="feeOptionalMenu"
                    >

                        <div class="sidebar-submenu">


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('student-fee-assignment.view')): ?>

                                <a
                                    href="<?php echo e(route('student-fee-assignments.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'student-fee-assignments.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Fee Assignments
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('optional-fee-assignment.view')): ?>

                                <a
                                    href="<?php echo e(route('optional-fee-assignments.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'optional-fee-assignments.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Optional Fee Assignment
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('concession-assignment.view')): ?>

                                <a
                                    href="<?php echo e(route('concession-assignments.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'concession-assignments.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Concession Assignment
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-waiver-assignment.view')): ?>

                                <a
                                    href="<?php echo e(route('fee-waiver-assignments.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'fee-waiver-assignments.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Fee Waiver Assignment
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fine-waiver-assignment.view')): ?>

                                <a
                                    href="<?php echo e(route('fine-waiver-assignments.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'fine-waiver-assignments.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Fine Waiver Assignment
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('composite-concession.view')): ?>

                                <a
                                    href="<?php echo e(route('composite-concessions.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'composite-concessions.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Composite Concession
                                </a>

                            <?php endif; ?>


                        </div>

                    </div>


                    

                    <a
                        data-bs-toggle="collapse"
                        href="#feeCollectionMenu"
                        role="button"
                        aria-expanded="<?php echo e($feeCollectionOpen ? 'true' : 'false'); ?>"
                        aria-controls="feeCollectionMenu"
                        class="<?php echo e($feeCollectionOpen ? 'active' : ''); ?>"
                    >

                        <i class="bi bi-currency-rupee me-2"></i>

                        <span class="flex-grow-1">
                            Fee Collection
                        </span>

                        <i class="bi bi-chevron-down sidebar-arrow"></i>

                    </a>


                    <div
                        class="collapse <?php echo e($feeCollectionOpen ? 'show' : ''); ?>"
                        id="feeCollectionMenu"
                    >

                        <div class="sidebar-submenu">


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-collection.view')): ?>

                                <a
                                    href="<?php echo e(route('fee-receipts.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'fee-receipts.*',
                                            'fee-collections.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Fee Receipts
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-refund.view')): ?>

                                <a
                                    href="<?php echo e(route('fee-refunds.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'fee-refunds.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Refund
                                </a>

                            <?php endif; ?>


                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cheque-dd.view')): ?>

                                <a
                                    href="<?php echo e(route('cheque-dd-details.index')); ?>"
                                    class="<?php echo e(request()->routeIs(
                                            'cheque-dd-details.*'
                                        )
                                        ? 'active'
                                        : ''); ?>"
                                >
                                    Cheque/DD Detail
                                </a>

                            <?php endif; ?>


                        </div>

                    </div>


                    

                    <a href="#">

                        <i class="bi bi-info-circle me-2"></i>

                        Instructions

                    </a>


                </div>

            </div>

        <?php endif; ?>


<?php echo $__env->make('accounts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php /**PATH C:\xampp\htdocs\school-erp\resources\views/partials/admin/menus/fees.blade.php ENDPATH**/ ?>