<aside class="admin-sidebar" id="adminSidebar">
    <div class="sidebar-brand"><a href="/dashboard"><img src="/assets/images/logo.png" style="width:100%;"></a></div>
    <div class="sidebar-menu">
        <div class="menu-title">Navigation</div>
        <a href="<?php echo e(route('dashboard')); ?>"><i class="bi bi-grid-3x3-gap"></i> Main Dashboard</a>
        <?php if(\Illuminate\Support\Facades\Route::has('all-modules')): ?>
            <a href="<?php echo e(route('all-modules')); ?>"><i class="bi bi-grid"></i> All Modules</a>
        <?php endif; ?>
        <?php
            $routeName = \Illuminate\Support\Facades\Route::currentRouteName() ?? '';
            $path = request()->path();
            $module = 'administration';
            if (str_starts_with($routeName, 'employee-information.') || request()->is('employee-information', 'employee-information/*')) {
                $module = 'employee';
            } elseif (str_starts_with($routeName, 'hr-payroll.') || str_starts_with($path, 'hr-payroll/') || str_starts_with($routeName, 'teacher.payroll.') || str_starts_with($routeName, 'teacher.staff-attendance.')) {
                $module = 'hr';
            } elseif (str_starts_with($routeName, 'teacher.') || str_starts_with($routeName, 'teacher-assignments.') || str_starts_with($path, 'teacher/')) {
                $module = 'teacher';
            } elseif (request()->is('fees', 'fees/*') || str_starts_with($routeName, 'fees.') || preg_match('/^(fee-|fee_|fee\.|student-fee|optional-fee|concession-|fine-waiver|composite-concession|cheque-dd)/', $routeName)) {
                $module = 'fees';
            } elseif (str_starts_with($routeName, 'admission-') || str_starts_with($routeName, 'admission.') || str_starts_with($path, 'admission/')) {
                $module = 'admission';
            } elseif (str_starts_with($routeName, 'student') || str_starts_with($routeName, 'tc-') || str_starts_with($routeName, 'promotion-statuses.')) {
                $module = 'students';
            } elseif (preg_match('/^(academic-year|school|wing|section|subject|class-subject|section-group|calendar-event-types|school-calendar)/', $routeName)) {
                $module = 'academic';
            } elseif (preg_match('/^(transport|inventory|communication|ticket|visitor)/', $routeName)) {
                $module = 'operations';
            }
        ?>
        <?php
            $currentUser = auth()->user();
            $permissionNames = $currentUser ? $currentUser->getAllPermissions()->pluck('name') : collect();
            $isAdministrator = $currentUser && $currentUser->hasAnyRole(['Super Admin', 'Admin']);
            $hasStudentMenuPermission = $isAdministrator || $permissionNames->contains(function ($permission) {
                return preg_match('/^(admission[.-]|student\.(?!fee)|student-admission\.|student-document\.|student-enrollment\.|student-promotion\.|student-attendance\.|promotion-status\.|tc-)/', $permission) === 1;
            });
            $hasAcademicMenuPermission = $isAdministrator || $permissionNames->contains(function ($permission) {
                return preg_match('/^(academic-year\.|school\.|wing\.|class\.|section\.|subject\.|class-subject\.|section-group\.|calendar-event-types\.|school-calendar\.)/', $permission) === 1;
            });
        ?>
        <?php if($module === 'employee'): ?>
            <?php echo $__env->make('partials.admin.menus.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($module === 'teacher'): ?>
            <?php echo $__env->make('partials.admin.menus.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($module === 'academic'): ?>
            <?php if($hasAcademicMenuPermission): ?>
                <?php echo $__env->make('partials.admin.menus.academic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php elseif($module === 'admission'): ?>
            <?php echo $__env->make('partials.admin.menus.admission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($module === 'students'): ?>
            <?php if($hasStudentMenuPermission): ?>
                <?php echo $__env->make('partials.admin.menus.students', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php elseif($module === 'fees'): ?>
            <?php echo $__env->make('partials.admin.menus.fees', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($module === 'hr'): ?>
            <?php echo $__env->make('partials.admin.menus.hr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($module === 'operations'): ?>
            <?php echo $__env->make('partials.admin.menus.operations', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('partials.admin.menus.administration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\school-erp\resources\views/partials/admin/sidebar.blade.php ENDPATH**/ ?>