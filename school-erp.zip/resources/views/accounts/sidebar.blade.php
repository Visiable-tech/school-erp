@can('accounts.view')
<div class="px-3 py-2"><a class="text-white text-decoration-none" href="{{ route('accounts.index') }}"><i class="bi bi-wallet2 me-2"></i>Accounts Dashboard</a></div>
<div class="px-3 py-2"><a class="text-white text-decoration-none" href="{{ route('accounts.expenses') }}"><i class="bi bi-receipt me-2"></i>Expense & Payments</a></div>
@can('accounts.category.manage')<div class="px-3 py-2"><a class="text-white text-decoration-none" href="{{ route('accounts.categories') }}">Expense Categories</a></div>@endcan
@endcan
@can('accounts.view')<div class="px-3 py-2"><a class="text-white text-decoration-none" href="{{ route('accounts.vendors.index') }}">Vendor Management &amp; Payments</a></div>@endcan
