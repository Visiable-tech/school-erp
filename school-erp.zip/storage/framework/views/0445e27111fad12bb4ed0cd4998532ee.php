<?php $__env->startSection('content'); ?>
<div class="container-fluid py-3">
<h3 class="text-success">Accounts & Payments</h3>
<div class="d-flex flex-wrap gap-2 mb-3"><a class="btn btn-outline-success" href="<?php echo e(route('accounts.index')); ?>">Accounts Dashboard</a><a class="btn btn-outline-success" href="<?php echo e(route('accounts.expenses')); ?>">Expense Register</a><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounts.category.manage')): ?><a class="btn btn-outline-success" href="<?php echo e(route('accounts.categories')); ?>">Expense Categories</a><?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fee-head.view')): ?><a class="btn btn-outline-secondary" href="<?php echo e(route('fees.dashboard')); ?>">Fee Dashboard</a><?php endif; ?></div>
<?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
<?php if($errors->any()): ?><div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
<a class="btn btn-outline-success mb-3" href="<?php echo e(route('accounts.vendors.index')); ?>">Vendor Management</a>
<?php echo $__env->yieldContent('accounts_content'); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-erp\resources\views/accounts/shell.blade.php ENDPATH**/ ?>