<footer class="admin-footer">

    <div class="d-flex
                justify-content-between
                align-items-center">

        <div>

            &copy; <?php echo e(date('Y')); ?>


            <?php echo e(auth()->user()?->school?->school_name ?? 'School ERP'); ?>


        </div>

        <div class="text-muted">

            School ERP

        </div>

    </div>

</footer><?php /**PATH C:\xampp\htdocs\school-erp\resources\views/partials/admin/footer.blade.php ENDPATH**/ ?>