

        <div class="menu-title">
            Administration
        </div>


        <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'Super Admin|Admin')): ?>
        <a href="<?php echo e(route('access.users.index')); ?>"><i class="bi bi-person-gear"></i> Users</a>
        <?php endif; ?>


        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Super Admin')): ?>
        <a href="<?php echo e(route('access.roles.index')); ?>"><i class="bi bi-shield-lock"></i> Roles & Permissions</a>
        <?php endif; ?>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Super Admin')): ?>
        <a href="<?php echo e(route('user-activity-logs.index')); ?>"><i class="bi bi-person-badge"></i> User Activity</a>
        <?php endif; ?>


        <a href="#">

            <i class="bi bi-gear"></i>

            Settings

        </a>

<?php /**PATH C:\xampp\htdocs\school-erp\resources\views/partials/admin/menus/administration.blade.php ENDPATH**/ ?>