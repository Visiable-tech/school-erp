

<?php if(!request()->is('dashboard')): ?>
    <header class="admin-header">
<?php else: ?> 
    <header class="admin-header" style="left:0;">
<?php endif; ?>

    <div class="container-fluid">

        <div class="d-flex
                    align-items-center
                    justify-content-between">

            <div class="d-flex align-items-center">

                <button
                    id="sidebarToggle"
                    class="btn btn-light me-3 d-lg-none">

                    <i class="bi bi-list"></i>

                </button>


                <div>

                    <a href="<?php echo e(route('modules.index')); ?>" class="all_modules" style="color: #000;
    margin-left: 30px;
    font-weight: bold;
    font-size: 18px;
    text-decoration: none;">
                        <i class="bi bi-grid-3x3-gap-fill"></i> All Modules
                    </a>

                    <a href="/dashboard"><img src="/assets/images/header_logo.png" style="height:auto; width:30%"></a>

                    

                </div>

            </div>


            <div class="dropdown">

                <button
                    class="btn dropdown-toggle"
                    type="button"
                    data-bs-toggle="dropdown">

                    <i class="bi bi-person-circle me-1"></i>

                    <?php echo e(auth()->user()?->name ?? 'ERP User'); ?>


                </button>


                <ul class="dropdown-menu dropdown-menu-end">

                    <li>

                        <span class="dropdown-item-text">

                            <small class="text-muted">
                                Role
                            </small>

                            <br>

                            <strong>
                                <?php echo e(auth()->user()?->getRoleNames()->implode(', ') ?? 'Guest'); ?>

                            </strong>

                        </span>

                    </li>


                    <li>
                        <hr class="dropdown-divider">
                    </li>


                    <li>

                        <form
                            method="POST"
                            action="<?php echo e(route('logout')); ?>">

                            <?php echo csrf_field(); ?>

                            <button
                                type="submit"
                                class="dropdown-item text-danger">

                                <i class="bi bi-box-arrow-right me-2"></i>

                                Logout

                            </button>

                        </form>

                    </li>

                </ul>

            </div>

        </div>

    </div>

</header><?php /**PATH C:\xampp\htdocs\school-erp\resources\views/partials/admin/header.blade.php ENDPATH**/ ?>