<?php
namespace App\Http\Controllers;
use App\Models\ErpEmployee;
use App\Models\ErpEmployeeEvent;
use App\Models\ErpEmployeeCertificate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Carbon\Carbon;

class EmployeeInformationController extends Controller {
 private function school(): int {return (int) auth()->user()->school_id;}
 private function employees(){return ErpEmployee::where('school_id',$this->school());}
 private function events(){return ErpEmployeeEvent::where('school_id',$this->school());}
 private function employee(int $id): ErpEmployee {return $this->employees()->findOrFail($id);}
 private function types(): array {return ['relieved'=>'Relieved Employees','suspension'=>'Employee Suspension','resignation'=>'Resignation','holiday'=>'Employee Holidays','extra_duty'=>'Extra Duties','remark'=>'Employee Remarks','mapping'=>'Employee Organization Mapping'];}
 public function dashboard(Request $request){
  $month=$request->input('month',now()->format('Y-m'));
  if(!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/',$month)) $month=now()->format('Y-m');
  $date=Carbon::createFromFormat('!Y-m',$month);
  $q=$this->employees();$total=(clone $q)->count();
  $new=(clone $q)->whereBetween('joining_date',[$date->copy()->startOfMonth()->toDateString(),$date->copy()->endOfMonth()->toDateString()])->count();
  $male=(clone $q)->whereRaw('LOWER(gender)=?', ['male'])->count();$female=(clone $q)->whereRaw('LOWER(gender)=?', ['female'])->count();
  $birthdays=(clone $q)->whereNotNull('dob')->pluck('dob');$avgAge=$birthdays->count()?round($birthdays->avg(fn($d)=>Carbon::parse($d)->diffInMonths(now())/12),1):null;
  $departments=(clone $q)->select('department','gender',DB::raw('COUNT(*) as total'))->groupBy('department','gender')->get();
  $service=(clone $q)->whereNotNull('joining_date')->get(['name','department','joining_date'])->map(fn($e)=>['name'=>$e->name,'department'=>$e->department?:'Unassigned','months'=>Carbon::parse($e->joining_date)->diffInMonths(now())])->sortByDesc('months')->take(8)->values();
  $joining=$this->employees()->whereBetween('joining_date',[$date->copy()->startOfMonth(),$date->copy()->endOfMonth()])->orderByDesc('joining_date')->limit(10)->get();
  $relieved=$this->events()->with('employee')->where('type','relieved')->whereBetween('event_date',[$date->copy()->startOfMonth(),$date->copy()->endOfMonth()])->latest('event_date')->limit(10)->get();
  $expiring=ErpEmployeeCertificate::where('school_id',$this->school())->with('employee')->whereBetween('expiry_date',[today(),today()->addDays(60)])->orderBy('expiry_date')->limit(10)->get();
  return view('employee-information.dashboard',compact('month','total','new','male','female','avgAge','departments','service','joining','relieved','expiring'));
 }
 public function index(Request $request){$query=$this->employees();if($request->filled('search')){$s=$request->search;$query->where(fn($q)=>$q->where('name','like',"%{$s}%")->orWhere('employee_code','like',"%{$s}%"));}if($request->filled('status'))$query->where('status',$request->status);$employees=$query->orderBy('name')->paginate(20)->withQueryString();return view('employee-information.index',compact('employees'));}
 public function create(){return view('employee-information.form',['employee'=>new ErpEmployee()]);}
 public function edit(int $id){return view('employee-information.form',['employee'=>$this->employee($id)]);}
 private function employeeData(Request $request, ?int $id = null): array {
    $data = $request->validate([
      'employee_code' => ['required','string','max:40',Rule::unique('erp_employees','employee_code')->where('school_id',$this->school())->ignore($id)],
            'salutation' => 'nullable|in:Mr,Mrs,Ms,Dr',
            'first_name' => 'nullable|string|max:255',
            'middle_name' => 'nullable|string|max:255',
            'last_name' => 'nullable|string|max:255',
            'short_name' => 'nullable|string|max:255',
            'gender' => 'nullable|in:Male,Female,Other',
            'dob' => 'nullable|date',
            'blood_group' => 'nullable|in:A+,A-,B+,B-,AB+,AB-,O+,O-',
            'marital_status' => 'nullable|in:Single,Married,Divorced,Widowed',
            'place_of_birth' => 'nullable|string|max:255',
            'category' => 'nullable|string|max:255',
            'religion' => 'nullable|string|max:255',
            'nationality' => 'nullable|string|max:255',
            'passport_expiry_date' => 'nullable|date',
            'official_email' => 'nullable|email|max:255',
            'user_type' => 'nullable|in:Teaching,Non-Teaching,Administrative',
            'designation' => 'nullable|string|max:255',
            'department' => 'nullable|string|max:255',
            'employment_type' => 'nullable|in:Permanent,Contract,Part-Time,Temporary',
            'joining_date' => 'required|date',
            'rejoin' => 'sometimes|boolean',
            'staff_category' => 'nullable|string|max:255',
            'probation_ends_on' => 'nullable|date',
            'reporting_authority' => 'nullable|string|max:255',
            'confirmation_date' => 'nullable|date',
            'create_user_login' => 'sometimes|boolean',
            'cost_center' => 'nullable|string|max:255',
            'pay_scale' => 'nullable|string|max:255',
            'is_principal' => 'sometimes|boolean',
            'coordinating_sections' => 'nullable|string|max:255',
            'coordinating_classes' => 'nullable|string|max:255',
            'salary_mode' => 'nullable|in:Bank,Cash,Cheque',
            'qualifications' => 'nullable|string|max:255',
            'specialization' => 'nullable|string|max:255',
            'specialization_subjects' => 'nullable|string|max:255',
            'experience_teaching_years' => 'nullable|integer|min:0|max:100',
            'experience_admin_years' => 'nullable|integer|min:0|max:100',
            'default_attendance_status' => 'nullable|in:Present,Absent,Leave',
            'previous_employee_code' => 'nullable|string|max:255',
            'increment_month' => 'nullable|in:January,February,March,April,May,June,July,August,September,October,November,December',
            'date_of_separation' => 'nullable|date',
            'status' => 'required|in:active,suspended,relieved,resigned',
            'phone' => 'nullable|string|max:255',
            'alternate_phone' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
            'address_from_date' => 'nullable|date',
            'address' => 'nullable|string|max:3000',
            'correspondence_country' => 'nullable|string|max:255',
            'correspondence_state' => 'nullable|string|max:255',
            'correspondence_city' => 'nullable|string|max:255',
            'correspondence_pincode' => 'nullable|string|max:255',
            'permanent_address' => 'nullable|string|max:3000',
            'same_as_correspondence' => 'sometimes|boolean',
            'permanent_country' => 'nullable|string|max:255',
            'permanent_state' => 'nullable|string|max:255',
            'permanent_city' => 'nullable|string|max:255',
            'permanent_pincode' => 'nullable|string|max:255',
            'father_salutation' => 'nullable|in:Mr,Dr',
            'father_name' => 'nullable|string|max:255',
            'father_contact' => 'nullable|string|max:255',
            'father_occupation' => 'nullable|string|max:255',
            'mother_salutation' => 'nullable|in:Mrs,Ms,Dr',
            'mother_name' => 'nullable|string|max:255',
            'mother_contact' => 'nullable|string|max:255',
            'mother_occupation' => 'nullable|string|max:255',
            'bank_from_date' => 'nullable|date',
            'pf_no' => 'nullable|string|max:255',
            'esi_no' => 'nullable|string|max:255',
            'bank_name' => 'nullable|string|max:255',
            'account_no' => 'nullable|string|max:255',
            'bank_other_org_accounts' => 'sometimes|boolean',
            'ifsc_code' => 'nullable|string|max:255',
            'pf_activation_date' => 'nullable|date',
            'pf_appear_date' => 'nullable|date',
            'uan_no' => 'nullable|string|max:255',
            'exclude_ptax' => 'sometimes|boolean',
            'eps_no' => 'nullable|string|max:255',
            'pan_no' => 'nullable|string|max:255',
            'aadhaar_no' => 'nullable|string|max:255',
            'voter_id_no' => 'nullable|string|max:255',
            'punch_card_no' => 'nullable|string|max:255',
            'skip_salary_generation' => 'sometimes|boolean',
            'salary_slip_format' => 'nullable|string|max:255',
            'skip_salary_months' => 'nullable|string|max:255',
            'exclude_from_substitution' => 'sometimes|boolean',
            'personal_meeting_link' => 'nullable|string|max:255',
            'allow_marking_locked_attendance' => 'sometimes|boolean',
            'emergency_contact' => 'nullable|string|max:255',
      'image_path' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:3072',
      'signature_path' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
    ]);
    $data['exclude_ptax'] = $request->boolean('exclude_ptax');
    $data['rejoin'] = $request->boolean('rejoin');
    $data['exclude_from_substitution'] = $request->boolean('exclude_from_substitution');
    $data['create_user_login'] = $request->boolean('create_user_login');
    $data['skip_salary_generation'] = $request->boolean('skip_salary_generation');
    $data['bank_other_org_accounts'] = $request->boolean('bank_other_org_accounts');
    $data['same_as_correspondence'] = $request->boolean('same_as_correspondence');
    $data['allow_marking_locked_attendance'] = $request->boolean('allow_marking_locked_attendance');
    $data['is_principal'] = $request->boolean('is_principal');
    $data['name'] = trim(implode(' ',array_filter([$data['first_name']??null,$data['middle_name']??null,$data['last_name']??null])));
    if ($data['name'] === '') { throw \Illuminate\Validation\ValidationException::withMessages(['first_name'=>'First name or last name is required.']); }
    foreach (['image_path','signature_path'] as $field) {
      unset($data[$field]);
      if ($request->hasFile($field)) {
        $data[$field] = $request->file($field)->store('employee-private/'.$this->school(), 'local');
      }
    }
    return $data;
 }
 public function store(Request $request){$data=$this->employeeData($request);$data['school_id']=$this->school();ErpEmployee::create($data);return redirect()->route('employee-info.index')->with('success','Employee added.');}
 public function update(Request $request,int $id){$e=$this->employee($id);$e->update($this->employeeData($request,$id));return redirect()->route('employee-info.index')->with('success','Employee updated.');}
 public function destroy(int $id){$e=$this->employee($id);if($e->events()->exists()||$e->certificates()->exists())return back()->with('error','Remove linked records before deleting employee.');$e->delete();return back()->with('success','Employee deleted.');}
 public function eventIndex(Request $request,string $type){abort_unless(isset($this->types()[$type]),404);$events=$this->events()->where('type',$type)->with('employee')->latest('event_date')->paginate(20);$employees=$this->employees()->orderBy('name')->get(['id','name','employee_code']);$title=$this->types()[$type];return view('employee-information.events',compact('events','employees','title','type'));}
 public function eventStore(Request $request,string $type){abort_unless(isset($this->types()[$type]),404);$data=$request->validate(['employee_id'=>'required|integer','event_date'=>'required|date','end_date'=>'nullable|date|after_or_equal:event_date','title'=>'nullable|string|max:255','remarks'=>'nullable|string|max:5000']);$employee=$this->employee((int)$data['employee_id']);$data['school_id']=$this->school();$data['type']=$type;DB::transaction(function()use($data,$employee,$type){ErpEmployeeEvent::create($data);$status=['relieved'=>'relieved','suspension'=>'suspended','resignation'=>'resigned'][$type]??null;if($status)$employee->update(['status'=>$status]);});return back()->with('success','Record saved.');}
 public function eventDestroy(string $type,int $id){abort_unless(isset($this->types()[$type]),404);$this->events()->where('type',$type)->findOrFail($id)->delete();return back()->with('success','Record deleted. Employee status must be reviewed separately.');}
 public function certificates(){ $certificates=ErpEmployeeCertificate::where('school_id',$this->school())->with('employee')->latest()->paginate(20);$employees=$this->employees()->orderBy('name')->get(['id','name','employee_code']);return view('employee-information.certificates',compact('certificates','employees'));}
 public function certificateStore(Request $request){$data=$request->validate(['employee_id'=>'required|integer','title'=>'required|string|max:255','expiry_date'=>'nullable|date','file'=>'required|file|mimes:pdf,jpg,jpeg,png|max:5120']);$this->employee((int)$data['employee_id']);$path=$request->file('file')->store('employee-certificates/'.$this->school(),'public');ErpEmployeeCertificate::create(['school_id'=>$this->school(),'employee_id'=>$data['employee_id'],'title'=>$data['title'],'expiry_date'=>$data['expiry_date']??null,'file_path'=>$path]);return back()->with('success','Certificate uploaded.');}
 public function certificateDownload(int $id){$cert=ErpEmployeeCertificate::where('school_id',$this->school())->findOrFail($id);abort_unless(Storage::disk('public')->exists($cert->file_path),404);return Storage::disk('public')->download($cert->file_path);}
 public function certificateDestroy(int $id){$cert=ErpEmployeeCertificate::where('school_id',$this->school())->findOrFail($id);Storage::disk('public')->delete($cert->file_path);$cert->delete();return back()->with('success','Certificate deleted.');}
 public function reports(Request $request){$query=$this->employees();if($request->filled('department'))$query->where('department',$request->department);if($request->filled('status'))$query->where('status',$request->status);$employees=$query->orderBy('name')->get();$departments=$this->employees()->whereNotNull('department')->distinct()->orderBy('department')->pluck('department');return view('employee-information.reports',compact('employees','departments'));}
}
