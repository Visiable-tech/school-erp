<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('student_fee_dues', function (Blueprint $table) {
            $table->decimal('fine_waiver_amount', 12, 2)
                ->default(0)
                ->after('fine_amount');
        });
    }

    public function down(): void
    {
        Schema::table('student_fee_dues', function (Blueprint $table) {
            $table->dropColumn('fine_waiver_amount');
        });
    }
};